<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home-Plan </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  <style>
	h3{
  font-family: Calibri; 
  font-size: 25pt;         
  font-style: normal; 
  font-weight: bold; 
  color:SlateBlue;
  text-align: center; 
  text-decoration: underline
}

table{
  font-family: Calibri; 
  color:black; 
  font-size: 11pt; 
  font-style: normal;
  font-weight: bold;
  text-align:; 
  background-color:SlateBlue; 
  border-collapse: collapse; 
  border: 2px solid navy
}
table.inner{
  border: 0px
}
	</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    			
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/eindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/eindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/engcal" class="nav-link">Calculate Budget </a></li>
	          <li class="nav-item"><a href="/planadd" class="nav-link">Draw Plans</a></li>
	          <li class="nav-item dropdown"><a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">View</a>
            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
													
                                
                          <a class="dropdown-item" href="/myplanv" class="trigger-btn"  title="">My Plans</a>
                          <a class="dropdown-item" href="/budgeteng"  class="trigger-btn"  title="">Budget</a>
                          <a class="dropdown-item" href="/reqplaneng"  class="trigger-btn"  title="">Requirement Plan</a>
                          <a class="dropdown-item" href="/uploadengselect"  class="trigger-btn"  title="">Uploaded Plans</a>
                          <a class="dropdown-item" href="/updateplan"  class="trigger-btn"  title="">Update Plans</a>
                      </div>
            </li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            {{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
													
                                
                                <a class="dropdown-item " href="/profilee" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <?php
$sess=session()->get('reg_id');
$a=$sess;
?>
    <section class="home-slider owl-carousel">
      <div class="slider-item" style="background-image:url(engineer/images/engineersp.jpg);">
      <form action="/plandesign" method="post"  enctype="multipart/form-data">
			@csrf
		<h1 align="center">	ADD PLANSS......</h1>
			<table align="center" cellpadding = "10">
 
 <!----- First Name ---------------------------------------------------------->
 <tr>
 <td>DESIGN PICTURE</td>
 <td> <input id="emails"  type="file" name="image"   required accept="image/*">
 <input type="hidden" name="email" value="{{$a}}">
 </td>
 </tr>
	
 <!----- Last Name ---------------------------------------------------------->
 <tr>
 <td>DEC</td>
 <td><textarea name="dec" rows="4" cols="30" pattern="[a-zA-Z\s]+" title="Enter valid format" required></textarea>

 </td>
 </tr>

 
	
 
 
	
 
 <tr>
 <td>AMOUNT <br ></td>

 <td> <input type="text" name="amount" maxlength="30" pattern="[0-9]{5}" title="Enter valid format" required/></td>
 </tr>
  <?php
  $t=DB::select("select * from tbl_plan");
  
  ?>
 <!----- City ---------------------------------------------------------->
 <tr>
  
 <td>TYPE</td>
 <td><select  name="type" required autofocus>
 <option value="Type">Type</option>
    @foreach($t as $s)
                                
                                <option value="{{$s->plan_id}}">{{$s->plan_type}}</option>
                                @endforeach
                            </select>
 
 </td>
 </tr>
 <tr>
 <td>AMOUNT OF DRAWING</td>
 <td><input type="text" name="amountss" maxlength="30" pattern="[0-9]{4}" title="Enter valid format" required/></textarea>

 </td>
 </tr>
 
 <tr>
 <td colspan="2" align="center">
 <input type="submit" value="Submit">
 <input type="reset" value="Reset">
 </td>
 </tr>
 </table>
	
 </form>
      </div>
    </section>

    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>