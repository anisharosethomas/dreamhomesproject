<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home-Engineers Home </title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
   <style>
	h3{
  font-family: Calibri; 
  font-size: 25pt;         
  font-style: normal; 
  font-weight: bold; 
  color:SlateBlue;
  text-align: ; 
  text-decoration: underline
}

table{
  font-family: Calibri; 
  color:white; 
  font-size: 11pt; 
  font-style: normal;
  font-weight: bold;
  background-color:black; 
  border-collapse: collapse; 
 
}
table.inner{
  border: 0px
}
	</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    			
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/eindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/eindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/engcal" class="nav-link">Calculate Budget </a></li>
	          <li class="nav-item"><a href="/planadd" class="nav-link">Draw Plans</a></li>
	          <li class="nav-item dropdown"><a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">View</a>
            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
													
                                
                          <a class="dropdown-item" href="/myplanv" class="trigger-btn"  title="">My Plans</a>
                          <a class="dropdown-item" href="/budgeteng"  class="trigger-btn"  title="">Budget</a>
                          <a class="dropdown-item" href="/reqplaneng"  class="trigger-btn"  title="">Requirement Plan</a>
                          <a class="dropdown-item" href="/uploadengselect"  class="trigger-btn"  title="">Uploaded Plans</a>
                          <a class="dropdown-item" href="/updateplan"  class="trigger-btn"  title="">Update Plans</a>
                      </div>
            </li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            {{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
													
                                
                                <a class="dropdown-item " href="/profilee" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    
    <h1 align="center"  style="color:#DB225D; text-align: center;">	UPDATE PLAN??......</h1>
    <?php
                        
                         if(count($st)=='0') 
                         {
                           echo"<h4 align='center'  style='color:black; text-align: center'>	NO RECORD FOUND......</h4>";
                         }
                         ?>
				@isset($st)
     @foreach($st as $approve)
    			
                 <div style="display: inline-block;">
    <form action="/planupdates" method="post"  enctype="multipart/form-data">
			@csrf
      <br>

		<input type="hidden" value="{{$approve->plandesign_id}}" name="bud"/>
<table  cellpadding = "5" style="width:350px;">
 
 <!----- First Name ---------------------------------------------------------->
 <tr>
 <td>PLAN</td>
 <td><a href="../images/{{$approve->plandesign_pic}}" target="_blank">View</a>

 </td>
 </tr>
 <tr>
 <td>EXTRA</td>
 <td><input type="text" name="area" value="{{$approve->plandesign_extra}}" required disabled/>
 
 </td>
 </tr>
 <tr>
 <td>CHANGE PLAN </td>
 <td> <input id="emails"  type="file" name="plan" required accept="image/*">
 
 </td>
 </tr>
 <!----- Last Name ---------------------------------------------------------->
 
 
 <!----- Last Name ---------------------------------------------------------->
 


       
   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;                                                                   <td><input type="submit" value="Select" name="accept"/></td> &nbsp;&nbsp;        
                                                                 
              <td><input type="submit" value="Cancel" name="accept"/></td>  &nbsp;&nbsp;      
                                                                  

 </tr>
 </table>

 </form>
</div>
					@endforeach
      @endisset
    
 
    

    
  
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>