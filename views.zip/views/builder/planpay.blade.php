<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home-Builder Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="builder/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="builder/css/animate.css">
    
    <link rel="stylesheet" href="builder/css/owl.carousel.min.css">
    <link rel="stylesheet" href="builder/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="builder/css/magnific-popup.css">

    <link rel="stylesheet" href="builder/css/aos.css">

    <link rel="stylesheet" href="builder/css/ionicons.min.css">

    <link rel="stylesheet" href="builder/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="builder/css/jquery.timepicker.css">

    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/styles.css">
    <link rel="stylesheet" type="text/css" href="assets/css/demo.css">
    <link rel="stylesheet" href="builder/css/flaticon.css">
    <link rel="stylesheet" href="builder/css/icomoon.css">
		<link rel="stylesheet" href="builder/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  <style>
  .btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}
  </style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/bindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/bindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/eapprove" class="nav-link">Approve Engineers</a></li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Upload
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                             
                                <a class="dropdown-item " href="/project" class="trigger-btn"  title="">Projects</a>
															
																<a class="dropdown-item " href="/int"  class="trigger-btn"  title="">Interior</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Payments
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/daily" class="trigger-btn" title="">Project Credits</a>
                                <a class="dropdown-item " href="/buildpay" class="trigger-btn" title="">Engineer Payment</a>
                             
															
                            </div>
												</li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    View
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/propertye" class="trigger-btn" title="">Projects</a>
                                <a class="dropdown-item " href="/viewint" class="trigger-btn"  title="">Interior</a>
																<a class="dropdown-item " href="/viewplan"  class="trigger-btn"  title="">Plans</a>
                                <a class="dropdown-item " href="/apporvebud" class="trigger-btn" title="">Buget</a>
                                <a class="dropdown-item " href="/builtreq" class="trigger-btn" title="">Requirement Plan</a>
                                <a class="dropdown-item " href="/uploadb" class="trigger-btn" title="">Uploaded Plans</a>
                            </div>
                        </li>

	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
														
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/profileb" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <div style="margin-top:10px; margin-left:150px;">
    <form action="/paymentbuilt" method="post">
    @csrf
   <b style="color:#DB225D;">REQUIREMENT PLAN</b>
    @foreach($st as $app)             
    
                         <table >
                             <thead>
                                 <tr>
                                 <td>
                                 <a href="#"><img src="images/{{$app->require_plan}}" alt="Product" width="100px" height="100px"></a>
                                
                                 <h5>{{$app->require_type}}</h5>
                                 <h5>{{$app->updated_at}}</h5>
                                
                                 <?php
                                 
                                 $v=$app->require_eng;
                                
                                 $tb=DB::select("select * from tbl_reg where reg_id='$v'");
                                 foreach($tb as $t)
                                 {
                                
                                 ?>
                                 </div>
                                 <h6>{{$t->reg_fname}} {{ $t->reg_sname}}</h6>
                                 <?php
                                }
                                
                                ?>
                                 <span>₹{{$app->require_eamount}}</span>
        <div style="float: right;">
        @if($app->require_status == 0)
       
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Not Payed</b>
        <input type="hidden" value="{{$app->require_eamount}}" name="require"/>
        <input type="hidden" value="{{$app->require_eng}}" name="r_eng"/>
       <input type="hidden" value="{{$app->require_id}}" name="require_id"/>
        @else
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Payed</b>
        @endif       
        
 
   </div>

     </div>
     </div>
@endforeach
<hr>
  <br>
  <b style="color:#DB225D;">PLAN DESIGN</b>
@foreach($sb as $apps)             
    
                         <table >
                             <thead>
                                 <tr>
                                 <td>
                                 <a href="#"><img src="images/{{$apps->plandesign_pic}}" alt="Product" width="100px" height="100px"></a>
                                
                                 <h5>{{$apps->plandesign_dec}}</h5>
                                 <h5>{{$apps->updated_at}}</h5>
                                 <?php
                                 
                                 $v=$apps->reg_id;
                                if($v!=0){
                                 $tb=DB::select("select * from tbl_reg where reg_id='$v'");
                                 foreach($tb as $t)
                                 {
                                   $name=$t->reg_fname;
                                   $sname=$t->reg_sname;
                                 }
                                 $p=$apps->plandesign_eamount;
                                 ?>
                                 </div>
                                 <h6>{{$name}} {{$sname}}</h6>
                                 <?php
                                 }
                                 ?>
                                 <span>₹{{$apps->plandesign_eamount}}</span>
                                 </div>
        <div style="float: right;">
        @if($apps->plandesign_status == 0)
       
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Not Payed</b>
       <input type="hidden" value="{{$apps->plandesign_eamount}}" name="plan"/>
       <input type="hidden" value="{{$apps->plandesign_id}}" name="plan_id"/>
       <input type="hidden" value="{{$apps->reg_id}}" name="p_eng"/>
        @else
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Payed</b>
        @endif       
        
 
   </div>

     </div>
     </div>
@endforeach
<br>
<hr>
<b style="color:#DB225D;">BUDGET</b>

@foreach($sv as $appss)             
    
                         <table >
                             <thead>
                                 <tr>
                                 <td>
                                
                                
                                 <h5>{{$appss->budget_type}}</h5>
                                 <h5>{{$appss->updated_at}}</h5>
                                 <?php
                                 
                                 $v=$appss->budget_eng;
                                if($v!='0'){
                                 $tb=DB::select("select * from tbl_reg where reg_id='$v'");
                                 foreach($tb as $t)
                                 {
                                   $name=$t->reg_fname;
                                   $sname=$t->reg_sname;
                                 }
                                 ?>
                                 </div>
                                 <h6>{{$name}} {{$sname}}</h6>
                                 <?php
                                 }
                                 $b=$appss->budget_eamount;
                                
                                 ?>
                                 <span>₹{{$appss->budget_eamount}}</span>
                                 </div>
        <div style="float: right;">
        @if($appss->budget_status == 0)
       
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Not Payed</b>
        <input type="hidden" value="{{$appss->budget_eamount}}" name="budget"/>
       <input type="hidden" value="{{$appss->budget_id}}" name="budget_id"/>
       <input type="hidden" value="{{$appss->budget_eng}}" name="b_eng"/>
        @else
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;<b> Payed</b>
        @endif       
        @endforeach
        <hr>
 <?php
 $b=0;
 $p=0;
 $r=$app->require_eamount;
 
 
 $tot=$r+$b+$p;
 $gst=$tot * 12/100;
 $total=$tot+$gst;
 ?>
 

    
      
    
    
      </div>
      <br>
      <br>
      <br>
      <div style="float: right;">
   <b>Total: {{$tot}}<br>
       GST :{{$gst}}<br>
       Total Amount:{{$total}}</b>
       <input type="hidden" name="total" value="{{$total}}"/>
       <input type="hidden" name="gst" value="{{$gst}}"/>
     </div>
      <div class="creditCardForm">
            <div class="heading">
                <h1>Confirm Payment</h1>
            </div>
            <div class="payment">
               
            <div class="form-group owner">
                        <label for="owner">Name on the Card</label>
                        <input type="text" class="form-control" id="owner" name="owner" >
                    </div>
                    <div class="form-group CVV">
                        <label for="cvv">CVV</label>
                        <input type="password" class="form-control" id="cvv" >
                    </div>
                    <div class="form-group" id="card-number-field">
                        <label for="cardNumber">Card Number</label>
                        <input type="text" class="form-control" id="cardNumber" name="cardno">
                    </div>
                    <div class="form-group" id="expiration-date">
                        <label>Expiration Date</label>
                        <select name="expmt">
                            <option value="01">January</option>
                            <option value="02">February </option>
                            <option value="03">March</option>
                            <option value="04">April</option>
                            <option value="05">May</option>
                            <option value="06">June</option>
                            <option value="07">July</option>
                            <option value="08">August</option>
                            <option value="09">September</option>
                            <option value="10">October</option>
                            <option value="11">November</option>
                            <option value="12">December</option>
                        </select>
                        <select name="expyr">
                            <option value="16"> 2016</option>
                            <option value="17"> 2017</option>
                            <option value="18"> 2018</option>
                            <option value="19"> 2019</option>
                            <option value="20"> 2020</option>
                            <option value="21"> 2021</option>
                        </select>
                    </div>
                    <div class="form-group" id="credit_cards">
                        <img src="assets/images/visa.jpg" id="visa">
                        <img src="assets/images/mastercard.jpg" id="mastercard">
                        <img src="assets/images/amex.jpg" id="amex">
                    </div>
                    <div class="form-group" id="pay-now">
                        <button type="submit"  class="btn btn-default"  name="confirm">Confirm</button>
                    </div>
               
                </form>
            </div>
        </div>

   
		

   
  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="builder/js/jquery.min.js"></script>
  <script src="builder/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="builder/js/popper.min.js"></script>
  <script src="builder/js/bootstrap.min.js"></script>
  <script src="builder/js/jquery.easing.1.3.js"></script>
  <script src="builder/js/jquery.waypoints.min.js"></script>
  <script src="builder/js/jquery.stellar.min.js"></script>
  <script src="builder/js/owl.carousel.min.js"></script>
  <script src="builder/js/jquery.magnific-popup.min.js"></script>
  <script src="builder/js/aos.js"></script>
  <script src="builder/js/jquery.animateNumber.min.js"></script>
  <script src="builder/js/bootstrap-datepicker.js"></script>
  <script src="builder/js/jquery.timepicker.min.js"></script>
  <script src="builder/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="builder/js/google-map.js"></script>
  <script src="builder/js/main.js"></script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery.payform.min.js" charset="utf-8"></script>
    <script src="assets/js/script.js"></script>
  </body>
</html>