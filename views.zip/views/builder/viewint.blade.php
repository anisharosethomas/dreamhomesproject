<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home-Interior</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="builder/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="builder/css/animate.css">
    
    <link rel="stylesheet" href="builder/css/owl.carousel.min.css">
    <link rel="stylesheet" href="builder/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="builder/css/magnific-popup.css">

    <link rel="stylesheet" href="builder/css/aos.css">

    <link rel="stylesheet" href="builder/css/ionicons.min.css">

    <link rel="stylesheet" href="builder/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="builder/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="builder/css/flaticon.css">
    <link rel="stylesheet" href="builder/css/icomoon.css">
		<link rel="stylesheet" href="builder/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/bindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/bindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/eapprove" class="nav-link">Approve Engineers</a></li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Upload
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                             
                                <a class="dropdown-item " href="/project" class="trigger-btn"  title="">Projects</a>
															
																<a class="dropdown-item " href="/int"  class="trigger-btn"  title="">Interior</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Payments
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/daily" class="trigger-btn" title="">Project Credits</a>
                                <a class="dropdown-item " href="/buildpay" class="trigger-btn" title="">Engineer Payment</a>
                             
															
                            </div>
												</li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    View
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/propertye" class="trigger-btn" title="">Projects</a>
                                <a class="dropdown-item " href="/viewint" class="trigger-btn"  title="">Interior</a>
																<a class="dropdown-item " href="/viewplan"  class="trigger-btn"  title="">Plans</a>
                                <a class="dropdown-item " href="/apporvebud" class="trigger-btn" title="">Buget</a>
                                <a class="dropdown-item " href="/builtreq" class="trigger-btn" title="">Requirement Plan</a>
                                <a class="dropdown-item " href="/uploadb" class="trigger-btn" title="">Uploaded Plans</a>
                            </div>
                        </li>

	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
														
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                
                                <a class="dropdown-item " href="/profileb" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    
    <section class="home-slider owl-carousel">
     
       <div class="container">
     
<?php
 $sess=session()->get('reg_id');
 $a=$sess;
  $st=DB::select("select * from tbl_interior,tbl_booking where tbl_booking.booking_builder='$a' and tbl_interior.interior_id=tbl_booking.interior_id");
?>
<div class="row">
@isset($st)
@foreach($st as $approve)
<form action="/appinterior" method="post">
@csrf
  <div class="col-md-4 ftco-animate" style="display:inline-block;">
    <div class="properties"  >
    
      <a href="" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/{{$approve->interior_pic}});">
        <div class="icon d-flex justify-content-center align-items-center" >
          <span class="icon-search2"></span>
        </div>
      </a>
      <div class="text p-3">
        <span class="status sale">Sale</span>
        <div class="d-flex">
          <div class="one">
            <h3><a href="">{{$approve->interior_dec}}</a></h3>
           <input type="hidden" value="{{$approve->interior_id}}" name="id"/>
           
          </div>
          <div class="two">
            <span class="price"> ₹{{$approve->interior_amount}}</span>
  <?php 
    $p=$approve->reg_id;
   // echo $p;
$dt=DB::select("select reg_fname,reg_sname from tbl_reg where reg_id='$p'")
?>
@foreach($dt as $app)
            <p>{{$app->reg_fname}}  {{$app->reg_sname}}</p>
            @endforeach							
          </div>
          <input type="hidden" value="{{$approve->reg_id}}" name="reg_id"/>
        </div>
      	
     <div align="right">
    @if($approve->booking_status == '0')        
                                                                     <td><input type="submit" value="Accept" name="accept"/></td> &nbsp;&nbsp;        
                                                                   @else
                                                                     <td><input type="submit" value="Reject" name="reject"/></td>  &nbsp;&nbsp;      
                                                                   @endif
    
  </div>
 
</div>
</div>
    </div>
    @endforeach
      @endisset
</div>
  </form>
        </div>
        </div>
      </div>
    </section>

   
		

   
  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="builder/js/jquery.min.js"></script>
  <script src="builder/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="builder/js/popper.min.js"></script>
  <script src="builder/js/bootstrap.min.js"></script>
  <script src="builder/js/jquery.easing.1.3.js"></script>
  <script src="builder/js/jquery.waypoints.min.js"></script>
  <script src="builder/js/jquery.stellar.min.js"></script>
  <script src="builder/js/owl.carousel.min.js"></script>
  <script src="builder/js/jquery.magnific-popup.min.js"></script>
  <script src="builder/js/aos.js"></script>
  <script src="builder/js/jquery.animateNumber.min.js"></script>
  <script src="builder/js/bootstrap-datepicker.js"></script>
  <script src="builder/js/jquery.timepicker.min.js"></script>
  <script src="builder/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="builder/js/google-map.js"></script>
  <script src="builder/js/main.js"></script>
    
  </body>
</html>