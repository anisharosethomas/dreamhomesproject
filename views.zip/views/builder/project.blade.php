<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="builder/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="builder/css/animate.css">
    
    <link rel="stylesheet" href="builder/css/owl.carousel.min.css">
    <link rel="stylesheet" href="builder/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="builder/css/magnific-popup.css">

    <link rel="stylesheet" href="builder/css/aos.css">

    <link rel="stylesheet" href="builder/css/ionicons.min.css">

    <link rel="stylesheet" href="builder/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="builder/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="builder/css/flaticon.css">
    <link rel="stylesheet" href="builder/css/icomoon.css">
    <link rel="stylesheet" href="builder/css/style.css">
    <style>
	h3{
  font-family: Calibri; 
  font-size: 25pt;         
  font-style: normal; 
  font-weight: bold; 
  color:SlateBlue;
  text-align: center; 
  text-decoration: underline
}

table{
  font-family: Calibri; 
  color:black; 
  font-size: 11pt; 
  font-style: normal;
  font-weight: bold;
  text-align:; 
  background-color:#B8860B; 
  border-collapse: collapse; 
  border: 2px solid navy
}
table.inner{
  border: 0px
}
	</style>
  </head>
  <body>
	<div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/bindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/bindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/eapprove" class="nav-link">Approve Engineers</a></li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Upload
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                             
                                <a class="dropdown-item " href="/project" class="trigger-btn"  title="">Projects</a>
															
																<a class="dropdown-item " href="/int"  class="trigger-btn"  title="">Interior</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Payments
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/daily" class="trigger-btn" title="">Project Credits</a>
                                <a class="dropdown-item " href="/buildpay" class="trigger-btn" title="">Engineer Payment</a>
                             
															
                            </div>
												</li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    View
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/propertye" class="trigger-btn" title="">Projects</a>
                                <a class="dropdown-item " href="/viewint" class="trigger-btn"  title="">Interior</a>
																<a class="dropdown-item " href="/viewplan"  class="trigger-btn"  title="">Plans</a>
                                <a class="dropdown-item " href="/apporvebud" class="trigger-btn" title="">Buget</a>
                                <a class="dropdown-item " href="/builtreq" class="trigger-btn" title="">Requirement Plan</a>
                                <a class="dropdown-item " href="/uploadb" class="trigger-btn" title="">Uploaded Plans</a>
                            </div>
                        </li>

	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
														
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                              
                                <a class="dropdown-item " href="/profileb" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <div class="slider-item" style="background-image:url(img/interior.jpg);"> 
<form action="{{route('projects')}}" method="post" enctype="multipart/form-data">
@csrf
<input type="hidden" name="_token" value="{{ csrf_token()}}">
<div class="form" >
</div>
<div class="form-group" >
<h1 align="center">	ADD PROJECTS.....</h1>
<div class="contains" style="align:center;"> 
<table align="left" cellpadding = "10" width="450" style="margin-top:10px; margin-left:150px;">
<tr>
 <td>Project Type</td>
 <td> <select  name="type" maxlength="30" required autofocus>
                                <option value="">Type</option>
                                <option value="1">Ongoing</option>
                                <option value="2">Upcoming</option>
                                <option value="3">Completed</option>
                            </select>
                            <input type="hidden" name="builder" value="	{{Session::get('reg_id')}}">
 </td>
 </tr>
 <tr>
 <td>Project Name</td>
 <td> 
 <input id="pname" type="text" autocomplete="off" name="pname" pattern="[a-zA-Z\s]+" title="Enter valid format" required autofocus>                        
 </td>
 </tr>
 <tr>
 <td>Address</td>
 <td> 
 <input id="sname" type="textarea" autocomplete="off"  name="add"  pattern="[a-zA-Z\s]+" title="Enter valid format" required autofocus rows="4" cols="30">                      
 </td>
 </tr>
 <tr>
 <td>Description</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault03" required name="dec">                    
 </td>
 </tr>
 <tr>
 <td>Lot Area</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]{4}" title="Enter valid format" required name="lot" maxlength="30">              
 </td>
 </tr>
                        
                               
 <tr>
 <td>Bed Room</td>
 <td> 
 <select  name="bed"  required autofocus>
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select> 
 </td>
 </tr>
 <tr>
 <td>Bath Room</td>
 <td> 
 <select  name="bath"  required autofocus>
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                            </select>
 </td>
 </tr>                   
 
 <tr>
 <td>Gargage</td>
 <td> 
 <select  name="gar"  required autofocus>
                                <option value=""></option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                               
                            </select>
 </td>
 </tr> 
 <tr>
 <td>Floor Area</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]{4}" title="Enter valid format" required name="floor">
 </td>
 </tr>
 <tr>
 <td>Year</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]{4}" title="Enter valid format" required name="year">
 </td>
 </tr>
 <tr>
 <td>Stories</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]" title="Enter valid format" required name="str">
 </td>
 </tr>
 <tr>
 <td>Quantity</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]{2}" title="Enter valid format" required name="qrt">
 </td>
 </tr>                                     
</table>
<table align="center" cellpadding = "10">
<tr>
 <td>Roofing</td>
 <td> 
 <input id="emails"  type="text" name="roof"  pattern="[a-zA-Z\s]+" title="Enter valid format" required autocomplete="off"  placeholder="" required="">
 </td>
 </tr>
 <tr>
 <td>Picture</td>
 <td> 
 <input id="emails"  type="file" name="image"  required=""  accept="image/*" required autocomplete="off">
 </td>
 </tr>
 <tr>
 <td>Pictures</td>
 <td> 
 <input id="emails"  type="file" name="video"  required accept="image/*">
 </td>
 </tr>              
 <tr>
 <td>Certificate</td>
 <td> 
 <input id="upload" type="file" name="images" required accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf" />
 </td>
 </tr>       
 <tr>
 <td>Amount</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" pattern="[0-9]{5}" title="Enter valid format" required name="amount">
 </td>
 </tr>
 <tr>
 <td>Type of Home </td>
 <td> 
 <select  name="home" required autofocus>
                                <option value=""></option>
                                <option value="Home">Home</option>
                                <option value="Flat">Flat</option>
                                <option value="Appartment">Appartment</option>
                                <option value="Villa">Villa</option>
                            </select>
 
 </td>
 </tr>
 <tr>
 <td>Type of Land </td>
 <td> 
 <select  name="land" required autofocus>
 <option value=""></option>
 <option value="Near to Town">Near to Town</option>
	                        <option value="Near to Beach">Near to Beach</option>
													<option value="Near to Temple">Near to Temple</option>
													<option value="Near to Church">Near to Church</option>
													<option value="Near to IT Park">Near to IT Park</option>
                            </select>
 
 </td>
 </tr>                            
 <tr>
 <td>Video  </td>
 <td> 
 <input id="emails"  type="file" name="videos"  required accept="video/*">
 </td>
 </tr>
 <?php
                        $s=DB::select("select * from tbl_district")
                        ?> 
 <tr>
 <td>District </td>
 <td> 
 <select  name="dis" required autofocus>
        
                                <option value=""></option>
                                @foreach($s as $app)
                                <option value="{{$app->district_name}}">{{$app->district_name}}</option>
                                @endforeach
                            </select>
 </td>
 </tr> 
 <tr>
 <td>Building Permit Number</td>
 <td> 
 <input type="text" autocomplete="off" id="validationDefault04" placeholder="" required="" name="per">
 </td>
 </tr>                        
                        
                                
                           
                            </td></tr>
						<tr><td align="center"><button type="submit" >Submit</button>
                            <button type="reset" >Cancel</button></td>
                        </tr>
                           </div>
                           </div>
</div>
</form>
<table> 
 </div> 
</div>
</div>
  <!-- loader -->


  <script src="builder/js/jquery.min.js"></script>
  <script src="builder/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="builder/js/popper.min.js"></script>
  <script src="builder/js/bootstrap.min.js"></script>
  <script src="builder/js/jquery.easing.1.3.js"></script>
  <script src="builder/js/jquery.waypoints.min.js"></script>
  <script src="builder/js/jquery.stellar.min.js"></script>
  <script src="builder/js/owl.carousel.min.js"></script>
  <script src="builder/js/jquery.magnific-popup.min.js"></script>
  <script src="builder/js/aos.js"></script>
  <script src="builder/js/jquery.animateNumber.min.js"></script>
  <script src="builder/js/bootstrap-datepicker.js"></script>
  <script src="builder/js/jquery.timepicker.min.js"></script>
  <script src="builder/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="builder/js/google-map.js"></script>
  <script src="builder/js/main.js"></script>
    
  </body>
</html>