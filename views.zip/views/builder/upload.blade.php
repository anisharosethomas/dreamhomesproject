<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home-Builder Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="builder/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="builder/css/animate.css">
    
    <link rel="stylesheet" href="builder/css/owl.carousel.min.css">
    <link rel="stylesheet" href="builder/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="builder/css/magnific-popup.css">

    <link rel="stylesheet" href="builder/css/aos.css">

    <link rel="stylesheet" href="builder/css/ionicons.min.css">

    <link rel="stylesheet" href="builder/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="builder/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="builder/css/flaticon.css">
    <link rel="stylesheet" href="builder/css/icomoon.css">
		<link rel="stylesheet" href="builder/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  <style>
	h3{
  font-family: Calibri; 
  font-size: 25pt;         
  font-style: normal; 
  font-weight: bold; 
  color:SlateBlue;
  text-align: center; 
  text-decoration: underline
}

table{
  font-family: Calibri; 
  color:black; 
  font-size: 11pt; 
  font-style: normal;
  font-weight: bold;
  text-align:; 
  background-color:SlateBlue; 
  border-collapse: collapse; 
  border: 2px solid navy
}
table.inner{
  border: 0px
}
	</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			<div class="col">
    				
    			</div>
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/bindex">DREAM<span>HOME</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/bindex" class="nav-link">Home</a></li>
	          <li class="nav-item"><a href="/eapprove" class="nav-link">Approve Engineers</a></li>
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Upload
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                             
                                <a class="dropdown-item " href="/project" class="trigger-btn"  title="">Projects</a>
															
																<a class="dropdown-item " href="/int"  class="trigger-btn"  title="">Interior</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Payments
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/daily" class="trigger-btn" title="">Project Credits</a>
                                <a class="dropdown-item " href="/buildpay" class="trigger-btn" title="">Engineer Payment</a>
                             
															
                            </div>
												</li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    View
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/propertye" class="trigger-btn" title="">Projects</a>
                                <a class="dropdown-item " href="/viewint" class="trigger-btn"  title="">Interior</a>
																<a class="dropdown-item " href="/viewplan"  class="trigger-btn"  title="">Plans</a>
                                <a class="dropdown-item " href="/apporvebud" class="trigger-btn" title="">Buget</a>
                                <a class="dropdown-item " href="/builtreq" class="trigger-btn" title="">Requirement Plan</a>
                                <a class="dropdown-item " href="/uploadb" class="trigger-btn" title="">Uploaded Plans</a>
                            </div>
                        </li>

	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
														
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                             
                                <a class="dropdown-item " href="/profileb" class="trigger-btn"  title="">Profile</a>
																
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <div class="rowa">
  <div class="col-75">
    <div class="containera">
   
    
</body>
 <!-- END nav -->
 <h1 align="center"  style="color:#DB225D; text-align: center">	SELECT ENGINEER....</h1>
    <?php
                         $sess=session()->get('reg_id');
                         $a=$sess;
                        // echo $a;
                         
                         if(count($st)=='0') 
                         {
                           echo"<h4 align='center'  style='color:black; text-align: center'>	NO RECORD FOUND......</h4>";
                         }
                         ?>
			
     @foreach($st as $app)
   
<?php
     $sess=session()->get('reg_id');
     $a=$sess;
    ?>
   
  
      <div class="slider-item" style="">
    <form action="/uploadeng" method="post"  enctype="multipart/form-data">
			@csrf
      <br>
<input type="hidden" value="{{$app->upload_id}}" name="id"/>
		<h1 align="center"  style="color:#00FF00;"></h1>
			<table align="center" cellpadding = "10" style="width:350px;">
 
 <!----- First Name ---------------------------------------------------------->
 <tr>
 <td>ENGINEER</td>
 <?php
 $c=DB::select("select * from tbl_reg,tbl_engineer where tbl_reg.reg_id=tbl_engineer.reg_id")
 ?>
 
 <td><select  name="builder" required autofocus>
 <option value="">Select One</option>                  
  @foreach($c as $t)
                              
                                <option value="{{$t->reg_id}}">{{$t->reg_fname}} {{$t->reg_sname}}</option>
                              
  @endforeach
                            </select>
 
 </td>
 </tr>
 <tr>
 <td>PLAN</td>
 <td> 
 <a href="../images/{{$app->upload_img}}" target="_blank">View</a>
 
 </td>
 </tr>
 <tr>
 <td>EXTRA NEEDS</td>
 <td><input type="text" name="extra" rows="4" cols="30" value="{{$app->upload_extra}}" disabled>

 </td>
 </tr>
 <!----- Last Name ---------------------------------------------------------->
 
 
 
 
 <td colspan="2" align="center">
 <input type="submit" value="OK" name="ok">
 <input type="reset" value="Cancel" name="cancel">
 </td>
 </tr>
 </table>

 </form>
</div>
      </div>
      @endforeach

   
  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="builder/js/jquery.min.js"></script>
  <script src="builder/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="builder/js/popper.min.js"></script>
  <script src="builder/js/bootstrap.min.js"></script>
  <script src="builder/js/jquery.easing.1.3.js"></script>
  <script src="builder/js/jquery.waypoints.min.js"></script>
  <script src="builder/js/jquery.stellar.min.js"></script>
  <script src="builder/js/owl.carousel.min.js"></script>
  <script src="builder/js/jquery.magnific-popup.min.js"></script>
  <script src="builder/js/aos.js"></script>
  <script src="builder/js/jquery.animateNumber.min.js"></script>
  <script src="builder/js/bootstrap-datepicker.js"></script>
  <script src="builder/js/jquery.timepicker.min.js"></script>
  <script src="builder/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="builder/js/google-map.js"></script>
  <script src="builder/js/main.js"></script>
    
  </body>
</html>