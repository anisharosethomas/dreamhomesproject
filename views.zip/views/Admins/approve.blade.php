<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Approve Customers</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- favicon
         ============================================ -->
    <link rel="shortcut icon" type="image/x-icon" href="img/favicon.ico">
    <!-- Google Fonts
         ============================================ -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
    <!-- Bootstrap CSS
         ============================================ -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Bootstrap CSS
         ============================================ -->
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <!-- adminpro icon CSS
         ============================================ -->
    <link rel="stylesheet" href="css/adminpro-custon-icon.css">
    <!-- meanmenu icon CSS
         ============================================ -->
    <link rel="stylesheet" href="css/meanmenu.min.css">
    <!-- animate CSS
         ============================================ -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- mCustomScrollbar CSS
         ============================================ -->
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.min.css">
    <!-- normalize CSS
         ============================================ -->
    <link rel="stylesheet" href="css/normalize.css">
    <!-- accordions CSS
         ============================================ -->
    <link rel="stylesheet" href="css/accordions.css">
    <!-- tabs CSS
		============================================ -->
    <link rel="stylesheet" href="css/tabs.css">
    <!-- style CSS
         ============================================ -->
    <link rel="stylesheet" href="style.css">
    <!-- responsive CSS
         ============================================ -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- modernizr JS
         ============================================ -->
    <script src="js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body class="materialdesign">
    <!--[if lt IE 8]>
      <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
      <![endif]-->
    <!-- Header top area start-->
    <div class="wrapper-pro">
        <div class="left-sidebar-pro">
            <nav id="sidebar">
                <div class="sidebar-header">
                    <a href="#"><img src="img/message/1.jpg" alt="" />
                    </a>
                    <h3>Admin</h3>
                    <p>Developer</p>
                    <strong></strong>
                </div>
                
                <div class="left-custom-menu-adp-wrap">
                    <ul class="nav navbar-nav left-sidebar-menu-pro">
                    <li class="nav-item"><a href="/dashboard" role="button" class="nav-link dropdown-toggle"><i class="fa big-icon fa-home"></i> <span class="mini-dn">Home</span> <span class="indicator-right-menu mini-dn"></span></a>
                            
                        </li>
                        
                       
                       
                        <li class="nav-item"><a href="/accordion" role="button" class="nav-link dropdown-toggle"><i class="fa big-icon fa-pie-chart"></i> <span class="mini-dn">Approve Builders</span> <span class="indicator-right-menu mini-dn"></span></a>
                            
                        </li>
                        <li class="nav-item"><a href="/approve"  role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-bar-chart-o"></i> <span class="mini-dn">Approve Customers</span> <span class="indicator-right-menu mini-dn"></span></a>
                            
                        </li>
                        <li class="nav-item"><a href="/plan"  role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-bar-chart-o"></i> <span class="mini-dn">Plan Type</span> <span class="indicator-right-menu mini-dn"></span></a>
                            
                        </li>
                        <li class="nav-item"><a href="/district"  role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-bar-chart-o"></i> <span class="mini-dn">Add District</span> <span class="indicator-right-menu mini-dn"></span></a>
                            
                            </li>
                        
                        <li class="nav-item"><a href="/loanadd"  role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-edit"></i> <span class="mini-dn">Loan Information</span> <span class="indicator-right-menu mini-dn"></span></a>
                           
                        </li>
                        
                    </ul>
                </div>
            </nav>
        </div>
        <!-- Header top area start-->
        <div class="content-inner-all">
            <div class="header-top-area">
                <div class="fixed-header-top">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-1 col-md-6 col-sm-6 col-xs-12">
                                <button type="button" id="sidebarCollapse" class="btn bar-button-pro header-drl-controller-btn btn-info navbar-btn">
                                    <i class="fa fa-bars"></i>
                                </button>
                                <div class="admin-logo logo-wrap-pro">
                                    <a href="#"><img src="img/logo/log.png" alt="" />
                                    </a>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-1 col-sm-1 col-xs-12">
                                <div class="header-top-menu tabl-d-n">
                                    
                                </div>
                            </div>
                            <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                                <div class="header-right-info">
                                    <ul class="nav navbar-nav mai-top-nav header-right-menu">
                                       
                                        
                                        <li class="nav-item">
                                            <a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle">
                                                <span class="adminpro-icon adminpro-user-rounded header-riht-inf"></span>
                                                <span class="admin-name">Admin</span>
                                                <span class="author-project-icon adminpro-icon adminpro-down-arrow"></span>
                                            </a>
                                            <ul role="menu" class="dropdown-header-top author-log dropdown-menu animated flipInX">
                                                <li><a href="/logout"><span class="adminpro-icon adminpro-locked author-log-ic"></span>Log Out</a>
                                                </li>
                                            </ul>
                                        </li>
                                      

                                            <div role="menu" class="admintab-wrap menu-setting-wrap menu-setting-wrap-bg dropdown-menu animated flipInX">
                                                

                                                <div class="tab-content">
                                                    
                                                    <div id="Projects" class="tab-pane fade">
                                                        <div class="projects-settings-wrap">
                                                            
                                                            <div class="project-st-list-area project-st-menu-scrollbar">
                                                                
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div id="Settings" class="tab-pane fade">
                                                        <div class="setting-panel-area">
                                                            <div class="note-heading-indicate">
                                                                <h2><i class="fa fa-gears"></i> Settings Panel</h2>
                                                                <p> You have 20 Settings. 5 not completed.</p>
                                                            </div>
                                                            <ul class="setting-panel-list">
                                                                
                                                               
                                                
                                                            </ul>

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Header top area end-->
            <!-- Breadcome start-->
            <div class="breadcome-area mg-b-30 small-dn">
                <div class="container-fluid">
                
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="breadcome-list map-mg-t-40-gl shadow-reset">
                                <div class="row">
                                    <div class="col-lg-6">
                                    <div class="breadcome-heading" >
                                            <form role="search" class="" action="/search">
												<input type="text" placeholder="Search..." name="search" class="form-control"  style="float: left;padding-right:10px;">
												<button type="submit"><i class="fa fa-search"></i></button>
											</form>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <ul class="breadcome-menu">
                                            <li><a href="/dashboard">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Approve Custosmers</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Breadcome End-->
            <!-- Mobile Menu start -->
                  <!-- Mobile Menu end -->
            <!-- Breadcome start-->
           
            <!-- accordion End-->
            <div class="sparkline9-list shadow-reset mg-tb-30" width="1000px" >
                                <div class="sparkline9-hd" style="width:1000px;">
                                    <div class="main-sparkline9-hd">
                                    <p><b>Unblocked Customers</b></p>
                                        <div class="sparkline9-outline-icon">
                                            <span class="sparkline9-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                           
                                            <span class="sparkline9-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline9-graph dashone-comment" style="width:1000px;">
                                        <table id="table1" data-toggle="table" data-pagination="true" data-show-columns="true" data-cookie="true" data-page-size="10" data-page-list="[10, 20, 30, 40, 50]" data-cookie-id-table="saveId">
                                            <thead>
                                                <tr>
                                                    <th data-field="status" data-editable="true">Name&nbsp;&nbsp; </th>
                                                    <th data-field="email" data-editable="true">&nbsp;&nbsp;Email Id&nbsp;&nbsp; </th>
                                                    <th data-field="phone" data-editable="true">Mobile Number&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Registraded Date&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Updated Date&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Status&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Approve/Reject&nbsp;&nbsp;</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                @isset($st)
                                                @foreach($st as $approve)
                                                @if($approve->login_status == '1') 
                                                     <td>{{$approve->reg_fname}}&nbsp;{{$approve->reg_sname}}</td>&nbsp;&nbsp;
                                                     <td>&nbsp;&nbsp;&nbsp;&nbsp;{{$approve->email}}&nbsp;&nbsp;&nbsp;&nbsp;</td>&nbsp;&nbsp;
                                                    
                                                    <td>{{$approve->reg_mob}}&nbsp;&nbsp;</td>
                                                    <td>{{$approve->created_at}}&nbsp;&nbsp;&nbsp;&nbsp;</td>&nbsp;&nbsp;
                                                    <td>{{$approve->updated_at}}</td>&nbsp;&nbsp;
                                                
        
                                                                   @if($approve->login_status == '1')        
                                                                     <td>Unblocked</td>   &nbsp;&nbsp;      
                                                                   @else
                                                                     <td>Blocked</td>  &nbsp;&nbsp;      
                                                                   @endif
                                                     
                                                    
                                                                  <td><a href="{{url('Approvec/'.$approve->login_id)}}">Change Status</a></td>
                                                                  <td><a href="{{url('Approvecu/'.$approve->login_id)}}">Delete</a></td>
                                                                 </tr>
                                                 
                                                    <br>
                                                    <br>
                                                    @endif
                                                @endforeach
                                               
                                             
                                                @endisset
                                                </tr>
                                                
                                            </tbody>
                                        </table>
                                       
                                    </div>  
                                </div>
                                        
                                <div class="sparkline9-list shadow-reset mg-tb-30"style="width:1000px;">
                                <div class="sparkline9-hd" style="width:1000px;">
                                    <div class="main-sparkline9-hd">
                                    <p><b>Blocked Customers</b></p>
                                        <div class="sparkline9-outline-icon">
                                            <span class="sparkline9-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                          
                                            <span class="sparkline9-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline9-graph dashone-comment" style="width:1000px;">
                                        <table id="table1" data-toggle="table" data-pagination="true" data-show-columns="true" data-cookie="true" data-page-size="10" data-page-list="[10, 20, 30, 40, 50]" data-cookie-id-table="saveId">
                                            <thead>
                                                <tr>
                                                    <th data-field="status" data-editable="true">Name&nbsp;&nbsp; </th>
                                                    <th data-field="email" data-editable="true">Email Id&nbsp;&nbsp; </th>
                                                    <th data-field="phone" data-editable="true">Mobile Number&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Registraded Date&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Updated&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Status&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Approve/Reject&nbsp;&nbsp;</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                @isset($st)
                                                @foreach($st as $approve)
                                                @if($approve->login_status == '0')   
                                                     <td>{{$approve->reg_fname}}&nbsp;{{$approve->reg_sname}}</td>&nbsp;&nbsp;&nbsp;&nbsp;
                                                     &nbsp;<td>{{$approve->email}}</td>&nbsp;&nbsp;
                                                    
                                                    <td>{{$approve->reg_mob}}</td>&nbsp;&nbsp;
                                                    <td>{{$approve->created_at}}</td>&nbsp;&nbsp;
                                                    <td>{{$approve->updated_at}}</td>&nbsp;&nbsp;
                                                
        
                                                                   @if($approve->login_status == '1')        
                                                                     <td>Unblocked</td> &nbsp;&nbsp;        
                                                                   @else
                                                                     <td>Blocked</td>  &nbsp;&nbsp;      
                                                                   @endif
                                                     
                                                    
                                                                  <td><a href="{{url('Approvec/'.$approve->login_id)}}">Change Status</a></td>
                                                                  <td><a href="{{url('Approvecu/'.$approve->login_id)}}">Delete</a></td>
                                                                 </tr>
                                                 <br>
                                                  <br>
                                                  @endif
                                                 @endforeach
                                                @endisset
                                               
                                                </tr>
                                            </tbody>
                                        </table>
                                             </div>
                                         </div>
                                    
                        </div>
        </div>
    </div>
    </div>
    </div></div>
    </div>
    
       
        </div>
    <div class="sparkline9-list shadow-reset mg-tb-30" style="width:1000px;" >
                                <div class="sparkline9-hd" style="width:1000px;">
                                    <div class="main-sparkline9-hd">
                                    <p><b> Other Details</b></p>
                                        <div class="sparkline9-outline-icon">
                                            <span class="sparkline9-collapse-link"><i class="fa fa-chevron-up"></i></span>
                                            
                                            <span class="sparkline9-collapse-close"><i class="fa fa-times"></i></span>
                                        </div>
                                    </div>
                                </div>
                                <div class="sparkline9-graph dashone-comment" style="width:1000px;">
                                    <div class="datatable-dashv1-list custom-datatable-overright dashtwo-project-list-data">
</div><table id="table1" data-toggle="table" data-pagination="true" data-show-columns="true" data-cookie="true" data-page-size="10" data-page-list="[10, 20, 30, 40, 50]" data-cookie-id-table="saveId">
                                            <thead>
                                                <tr>
                                                    <th data-field="status" data-editable="true">Builder Name&nbsp;&nbsp; </th>
                                                    <th data-field="email" data-editable="true">Land Mark&nbsp;&nbsp; </th>
                                                    <th data-field="phone" data-editable="true">Working Days&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Working Time&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Licence Number&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">Licence Document&nbsp;&nbsp;</th>
                                                    <th data-field="company" data-editable="true">District&nbsp;&nbsp;</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                @isset($s)
                                                @foreach($s as $approve)
                                              
                                                     <td>{{$approve->reg_id}}&nbsp;</td>&nbsp;&nbsp;
                                                     &nbsp;<td>{{$approve->b_land}}</td>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    
                                                    <td>{{$approve->b_day}}</td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <td>{{$approve->b_time}}</td>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <td>{{$approve->b_licence}}</td>&nbsp;&nbsp;&nbsp;&nbsp;
                                                    <td><a href='/images/{{$approve->b_licencdoc}}'></a></td>&nbsp;&nbsp;
                                                    <td>{{$approve->b_district}}</td>&nbsp;&nbsp;
                                                 
                                                 
                                                 <br>
                                                  <br>
                                             
                                                @endforeach
                                                @endisset
                                               
                                                </tr>
                                                
                                            </tbody>
                                        </table>
</div>
</div>
</div>
</div>
</div>
                </div>
                </div>                    </div>
                                </div>
                            </div>
                        </div>
                        </div>
                        </div>
        </div>
    <!-- Footer Start-->
    <div class="footer-copyright-area">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="footer-copy-right">
                                           </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Footer End-->
    <!-- jquery
         ============================================ -->
    <script src="js/vendor/jquery-1.11.3.min.js"></script>
    <!-- bootstrap JS
         ============================================ -->
    <script src="js/bootstrap.min.js"></script>
    <!-- meanmenu JS
         ============================================ -->
    <script src="js/jquery.meanmenu.js"></script>
    <!-- sticky JS
         ============================================ -->
    <script src="js/jquery.sticky.js"></script>
    <!-- mCustomScrollbar JS
         ============================================ -->
    <script src="js/jquery.mCustomScrollbar.concat.min.js"></script>
    <!-- scrollUp JS
         ============================================ -->
    <script src="js/jquery.scrollUp.min.js"></script>
    <!-- main JS
         ============================================ -->
    <script src="js/main.js"></script>
</body>

</html>