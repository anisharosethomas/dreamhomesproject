<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Single Property</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('customer/css/open-iconic-bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/animate.css')}}">
    
    <link rel="stylesheet" href="{{asset('customer/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/owl.theme.default.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/magnific-popup.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/aos.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/ionicons.min.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/bootstrap-datepicker.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/jquery.timepicker.css')}}">

    
    <link rel="stylesheet" href="{{asset('customer/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/icomoon.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/style.css')}}">
    
    <style>
.dropbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px;
  font-size: 16px;
  border: none;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f1f1f1;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color: #ddd;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #3e8e41;}
.collapsible {
  background-color: #777;
  color: white;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  border: none;
  text-align: left;
  outline: none;
  font-size: 15px;
}

.active, .collapsible:hover {
  background-color: #555;
}

.content {
  padding: 0 18px;
  display: none;
  overflow: hidden;
  background-color: #f1f1f1;
}
</style>

  </head>
	
  <body>
  <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

  
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <p class="breadcrumbs" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">
          </div>
        </div>
      </div>
    </div>
		@isset($st)
     @foreach($st as $approve)

    <section class="ftco-section">
      <div class="container" >
        <div class="row">
          <div class="col-lg-8">
          	
			<div class="column"  style="width:1400px;float:left;margin:5px;padding:5px;">
			
          		<div class="col-md-12 ftco-animate" style="width:600px;padding-right:10px;float:left;margin:5px;padding:5px;">
          			<div class="single-slider owl-carousel">
          				<div class="item">
          					<div class="properties-img" style="background-image: url(../images/{{$approve->project_image}});"></div>
          				</div>
          				<div class="item">
          					<div class="properties-img" style="background-image: url(../images/{{$approve->project_video}});"></div>
          				</div>
          				
          			</div>
          		</div>
         <div class="col-lg-4 sidebar ftco-animate" style="margin-top:2px;width:600px;margin:2px;float:left;padding:5px;">
            <div class="sidebar-box">
             
            </div>
           
         
            <?php
          
               $sess=session()->get('reg_id');
               $a=$sess;
             
               $s=DB::select("select reg_id from tbl_reg where reg_id='$a'");
               $sb=DB::select("select wish_name from tbl_wish where reg_id='$a'"); 
               foreach($st as $approve)
               {
                 $p=$approve->project_id;
                
               }  
              
            ?>
             <form method="post" action="/wish">@csrf
         <input type="hidden" value="{{$a}}" name="reg"/>
         <input type="hidden" value="{{$approve->project_id}}" name="wish"/>
         <div class="dropdown"  style="margin-top:2px;width:500px;margin:2px;padding:3px;">
           <input type="submit" name="submit" value=" Add to Wish List" >&nbsp;&nbsp;
           
            <div class="dropdown-content">
      @isset($sb)
     @foreach($sb as $app)
            <a href="/wish">{{$app->wish_name}}</a>
            @endforeach
      @endisset
           
      
      
	   </div> 
	   </form>
	<div class="differ"  style="margin-top:2px;width:300px;margin:2px;padding:2px;float:right;">
  <form method="post" action="/book">
            @csrf
            <input type="hidden" value="{{$approve->project_id}}" name="wish"/>
            <a href="/book"><button name="book" ><span class="icon-user" ></span> Book Now</button></a>&nbsp;&nbsp;
            </form>
      
    </form> 
    </div>
     
   
    </div>
    </div>
	 </div>
      </div>   
     
            </div>
           
          		<div class="col-md-12 Properties-single mt-4 mb-5 ftco-animate">
          			<h2>{{$approve->project_name}}</h2><h3 style="color:red;"> ₹ {{$approve->project_amount}}</h3>
               
          			<p class="rate mb-4">
          				<span class="loc"><a href="{{url('single/'.$approve->project_id)}}"><i class="icon-map"></i> {{$approve->project_add}}</a></span>
    					<br>	<h1> 
                 <b>{{$approve->project_permit}}</b></h1>
                  <b>{{$approve->created_at}}</b>
                </p>
    						<p>{{$approve->project_dec}}</p>
    						<div class="d-md-flex mt-5 mb-5">
    							<ul>
	    							<li><span>Lot Area: </span> {{$approve->project_lot}}</li>
	    							<li><span>Bed Rooms: </span> {{$approve->project_bd}}</li>
	    							<li><span>Bath Rooms: </span> {{$approve->project_bt}}</li>
	    							<li><span>2 Garage: </span> {{$approve->project_gd}}</li>
										<li><span>Land Type: </span> {{$approve->project_land}}</li>
                   
	    						</ul>
	    						<ul class="ml-md-5">
	    							<li><span>Floor Area: </span> {{$approve->project_fa}}</li>
	    							<li><span>Year Build: </span> {{$approve->project_yr}}</li>
	    							<li><span>Stories: </span> {{$approve->project_st}}</li>
	    							<li><span>Roofing: </span> {{$approve->project_rf}}</li>
										<li><span>Certificate: </span><a href="../images/{{$approve->project_cert}}" target="_blank">View</a></li>
									</ul>
    						</div>	
          		</div>
              <div class="col-md-12 properties-single ftco-animate mb-5 mt-4" style="width:650px;">
          			<h3 class="mb-4">Take A Tour</h3>
          			<div class="block-16">
		              <figure>
		                <button><img src="../images/{{$approve->project_image}}" alt="Image placeholder" class="img-fluid" ></button>
		                <a href="../images/{{$approve->project_videos}}" class="play-button popup-vimeo"  ><span class="icon-play"></span></a>
		                <a href="../images/{{$approve->project_videos}}" class="play-button popup-vimeo"  ><span class="icon-play"></span></a>
		              </figure>
		            </div>
          		</div>
      @endforeach
      @endisset
      
              <div class="modal fade" id="exampleModalCenter2" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header text-center">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="login px-4 mx-auto mw-100">
                        <h5 class="modal-title text-center text-dark mb-4">CREATE NEW WISHLIST</h5>
						<form action="{{route('wishadd')}}" method="post">
                            @csrf
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mx-3">
        <div class="md-form mb-5">
          <i class="fas fa-envelope prefix grey-text"></i>
          <label data-error="wrong" data-success="right">List Name</label>
          <input type="text" name="name" class="form-control"/>
          
         
        </div>

        <div class="md-form mb-4">
          <i class="fas fa-lock prefix grey-text"></i>
         
          <label data-error="wrong" data-success="right" for="defaultForm-pass">Privacy</label>
          <div class="form-group">
                            <div >
                            <?php
                             $sess=session()->get('reg_id');
                             $a=$sess;
                            $er=DB::select("select * from tbl_wish where reg_id='1'");
                            ?>
                             @foreach($er as $appr)
                                <input type="button" class="collapsible" name="privacys" value="{{$appr->wish_name}}"/>
                              @endforeach

<div class="content">
  <p>People can search for your public lists using your recipient name. When finding your public lists, they will see your recipient name, birthday and city. To edit this information, go to Manage List on your list page.</p>
  <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Recipient Name</label>
							<div class="right-w3l">
                        <div class="form-group">
                        <?php
                             $sess=session()->get('reg_id');
                             $a=$sess;
                            $ep=DB::select("select * from tbl_reg where reg_id='$a'");
                            
                            ?>
 <input type="hidden" value="{{$a}}" name="reg"/>
                             @foreach($ep as $appro)
                            
                                <input type="text" name="recp" class="form-control" value="{{$appro->reg_fname}} {{$appro->reg_sname}}" disabled/>
                                @endforeach
                            </div>
							</div>
        </div>

      </div>
      <div class="modal-footer d-flex justify-content-center">
        <button class="btn btn-default">Submit</button>
      </div>
    </div>
  </div>
</div>
 </section>
<?php
foreach($st as $s){
$see=$s->project_home;

}

$d=DB::select("select * from tbl_project where project_home='$see'")
?>
 
          		<div class="col-md-12 properties-single ftco-animate mb-5 mt-5">
          			<h4 class="mb-4">Related Properties</h4>
              
          			
					  @isset($d)
     @foreach($d as $prop)
	 <div class="row" style="width:500px;display:inline-block">
          				<div class="col-md-6 ftco-animate" >
				    				<div class="properties" style="width:450px;display:inline-block">
				    					<a href="{{url('single/'.$prop->project_id)}}" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(../images/{{$prop->project_image}});">
				    						<div class="icon d-flex justify-content-center align-items-center">
				    							<span class="icon-search2"></span>
				    						</div>
				    					</a>
				    					<div class="text p-3">
				    						<span class="status sale">Sale</span>
				    						<div class="d-flex">
				    							<div class="one">
						    						<h3><a href="{{url('single/'.$prop->project_id)}}">{{$prop->project_add}}</a></h3>
						    						<p>{{$prop->project_home}}</p>
					    						</div>
					    						<div class="two">
					    							<span class="price">₹{{$prop->project_amount}}</span>
				    							</div>
				    						</div>
				    						<p>{{$prop->project_dec}}</p>
				    						<hr>
				    						<p class="bottom-area d-flex">
				    							<span><i class="flaticon-selection"></i> {{$prop->project_lot}}</span>
				    							<span class="ml-auto"><i class="flaticon-bathtub"></i> {{$prop->project_bt}}</span>
				    							<span><i class="flaticon-bed"></i> {{$prop->project_bd}}</span>
				    						</p>
				    					</div>


                                      </div>										
                         </div>								
</div>
                  
               
              @endforeach
                    @endisset 
				    			
           <!-- .col-md-8 -->
         
             <!-- .section -->
		
	 

    
    


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
  <script>
var coll = document.getElementsByClassName("collapsible");
var i;

for (i = 0; i < coll.length; i++) {
  coll[i].addEventListener("click", function() {
    this.classList.toggle("active");
    var content = this.nextElementSibling;
    if (content.style.display === "block") {
      content.style.display = "none";
    } else {
      content.style.display = "block";
    }
  });
}
$('.product-list').on('change', function() {
        $('.product-list').not(this).prop('checked', false);  
    });
</script>

  <script src="{{asset('customer/js/jquery.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery-migrate-3.0.1.min.js')}}"></script>
  <script src="{{asset('customer/js/popper.min.js')}}"></script>
  <script src="{{asset('customer/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.easing.1.3.js')}}"></script>
  <script src="{{asset('customer/js/jquery.waypoints.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.stellar.min.js')}}"></script>
  <script src="{{asset('customer/js/owl.carousel.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.magnific-popup.min.js')}}"></script>
  <script src="{{asset('customer/js/aos.js')}}"></script>
  <script src="{{asset('customer/js/jquery.animateNumber.min.js')}}"></script>
  <script src="{{asset('customer/js/bootstrap-datepicker.js')}}"></script>
  <script src="{{asset('customer/js/jquery.timepicker.min.js')}}"></script>
  <script src="{{asset('customer/js/scrollax.min.js')}}"></script>
  <script src="{{asset('customer/js/google-map.js')}}"></script>
  <script src="{{asset('customer/js/main.js')}}"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.2.3/jquery.min.js"></script>
  </body>
</html>