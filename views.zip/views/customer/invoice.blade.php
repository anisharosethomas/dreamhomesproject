<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
   
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  </head>
  
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

   
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <body>
<div class="container">
        <div class="row">
                <div class="col-12">
<?php
//$mytime = Carbon\Carbon::now();
 

$ts= date("d-m-Y");
$date = date("Y-m-d H:i:s");
$sess=session()->get('reg_id');
 $a=$sess;
 //echo $project;
 $v=DB::select("select * from tbl_reg,logins where tbl_reg.reg_id=logins.reg_id and tbl_reg.reg_id='$a'");
 $vp=DB::select("select * from tbl_payment where reg_id='$a' and project_id='$project' and payment_status='0'");
 $f=count($vp);
 $r=$f+1;
 
 foreach($vp as $p)
 {
    $vs= $p->payment_builder;
    $pr=$p->project_id;
   $da=$p->updated_at;
    $t=$p->payment_id;
    $total=$p->payment_total;
    
 }
 $message = "$total is debited from your Account next payment after Agreement";
 echo "<script type='text/javascript'>alert('$message');</script>";
 $vn=DB::select("select * from tbl_reg,logins where tbl_reg.reg_id=logins.reg_id and tbl_reg.reg_id='$vs'");
 $g=DB::select("select * from tbl_project,tbl_payment where tbl_project.project_id='$pr' and tbl_payment.payment_id='$t'");
?>
                        <!-- Main content -->
                        <div class="invoice p-3 mb-3">
                          <!-- title row -->
                          <div class="row">
                            <div class="col-12">
                              <h4>
                                <i class="fa fa-globe"></i> DREAM HOME
                                <small class="float-right">Date:{{$ts}} </small>
                              </h4>
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- info row -->
                          <div class="row invoice-info">
                            <div class="col-sm-4 invoice-col">
                              From
                              @foreach($v as $u)
                              <address>
                             
                                <strong>{{$u->reg_fname}} {{$u->reg_sname}}</strong><br>
                                Phone: {{$u->reg_mob}}<br>
                                Email: {{$u->email}}
                              </address>
                              @endforeach
                            </div>
                            <!-- /.col -->
                            <div class="col-sm-4 invoice-col">
                              To
                              @foreach($vn as $up)
                              <address>
                                <strong>{{$up->reg_fname}} {{$up->reg_sname}}</strong><br>
                                Phone: {{$up->reg_mob}}<br>
                                Email: {{$up->email}}
                              </address>
                              @endforeach
                            </div>
                            <!-- /.col -->
                            <div class="col-sm-4 invoice-col">
                              <b>Invoice #00761{{$r}}</b><br>
                              <br>
                             
                              <b>Order ID:</b> 4F{{$f}}J<br>
                              @foreach($g as $t)
                              <b>Payment Due:</b> {{$t->created_at}}<br>
                          
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- /.row -->

                          <!-- Table row -->
                          <div class="row">
                            <div class="col-12 table-responsive">
                              <table class="table table-striped">
                                <thead>
                                <tr>
                                  <th>Qty</th>
                                  <th>Project</th>
                                  <th>Serial #</th>
                                  <th>Description</th>
                                  <th>Subtotal</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                @foreach($g as $y)
                                  <td>1</td>
                                  <td>{{$y->project_name}}</td>
                                  <td>455-981-221</td>
                                  <td>{{$y->project_dec}}</td>
                                  <td>₹{{$y->project_amount}}</td>
                                  @endforeach
                                </tr>

                               
                                </tbody>
                              </table>
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- /.row -->

                          <div class="row">
                            <!-- accepted payments column -->
                            <div class="col-6">
                              <p class="lead"></p>
                              
                              <p class="text-muted well well-sm no-shadow" style="margin-top: 10px;">
                                
                              </p>
                            </div>
                            <!-- /.col -->
                            <div class="col-6">
                              <p class="lead">Amount Due :{{$date}}</p>

                              <div class="table-responsive">
                                <table class="table">
                                  <tbody><tr>
                                    <th style="width:50%">Subtotal:</th>
                                    @foreach($g as $y)

<td>₹{{$y->project_amount}}</td>
@endforeach
                                  </tr>
                                  <tr>
                                    <th>GST (18%)</th>
                                    <td>₹{{$t->payment_gst}}</td>
                                  </tr>
                                  
                                  <tr>
                                    <th>Total:</th>
                                    <td>₹{{$t->payment_total}}</td>
                                  </tr>
                                </tbody></table>
                              </div>
                            </div>
                            <!-- /.col -->
                          </div>
                          <!-- /.row -->
   @endforeach
                          <!-- this row will not appear when printing -->
                          <div class="row no-print">
                            <div class="col-12">

                              
                              <button onclick="javascript:window.print()">Print</button>



                            </div>
                          </div>

                        </div>
                        <!-- /.invoice -->
                      </div>


        </div>
    </div>
    </div>
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>

    <script>
         let doc = new jsPDF(‘p’, ‘pt’, ‘a4’); 
         doc.addHTML(document.body, function () {
             doc.save(‘Bill.pdf’);
         });
    </script>
  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/1.3.5/jspdf.debug.js"></script>
  </body>
</html>