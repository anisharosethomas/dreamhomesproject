<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
body {
  font-family: Arial;
  font-size: 17px;
  padding: 8px;
}

* {
  box-sizing: border-box;
}

.rows {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  margin: 0 -16px;
}

.col-25 {
  -ms-flex: 25%; /* IE10 */
  flex: 25%;
}

.col-50 {
  -ms-flex: 50%; /* IE10 */
  flex: 50%;
}

.col-75 {
  -ms-flex: 75%; /* IE10 */
  flex: 75%;
}

.col-25,
.col-50,
.col-75 {
  padding: 0 16px;
}

.containers {
  background-color: #f2f2f2;
  padding: 5px 20px 15px 20px;
  border: 1px solid lightgrey;
  border-radius: 3px;
}

input[type=text] {
  width: 100%;
  margin-bottom: 20px;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 3px;
}

label {
  margin-bottom: 10px;
  display: block;
}

.icon-container {
  margin-bottom: 20px;
  padding: 7px 0;
  font-size: 24px;
}

.btn {
  background-color: #4CAF50;
  color: white;
  padding: 12px;
  margin: 10px 0;
  border: none;
  width: 100%;
  border-radius: 3px;
  cursor: pointer;
  font-size: 17px;
}

.btn:hover {
  background-color: #45a049;
}

a {
  color: #2196F3;
}

hr {
  border: 1px solid lightgrey;
}

span.price {
  float: right;
  color: grey;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other (also change the direction - make the "cart" column go on top) */
@media (max-width: 800px) {
  .row {
    flex-direction: column-reverse;
  }
  .col-25 {
    margin-bottom: 20px;
  }
}
</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>
   
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <div class="rowa">
  <div class="col-75">
    <div class="containera">
    <form action="/action_page.php">
    <?php
          $sess=session()->get('reg_id');
          $a=$sess;
          $st=DB::select("select * from logins,tbl_reg where tbl_reg.reg_id='$a' and logins.reg_id=tbl_reg.reg_id");
        ?>
         @isset($st)
     @foreach($st as $apps)
      <div class="row">
        <div class="col-50">
          <h3>Billing Address</h3>
          <label for="fname"><i class="fa fa-user"></i> Full Name</label>
          <input type="text" id="fname" name="firstname" value="{{$apps->reg_fname}} {{$apps->reg_sname}}">
          <label for="email"><i class="fa fa-envelope"></i> Email</label>
          <input type="text" id="email" name="email" value="{{$apps->email}}">
          

          <div class="row">
            
            <div class="col-50">
              
            </div>
          </div>
        </div>
        @endforeach
      @endisset
        <?php
          $sess=session()->get('reg_id');
          $a=$sess;
        $v=DB::select("select * from tbl_wishlist where reg_id='$a' and wish_status='0' and NOT project_id='NULL'");
        $p=count($v);
        foreach($v as $c){
          $b=$c->project_id;
          
        }
       // echo $b;
        $user = DB::select("select * from tbl_project,tbl_wishlist where tbl_project.project_id='$b' and tbl_project.project_id=tbl_wishlist.project_id and tbl_wishlist.reg_id='$a'");
        //foreach($user as $p){
         //$e=$c->project_amount;
         // $t=$e+$e;
        //}
       ?>
        <div class="col-25">
  <div class="container">
  
  
    @isset($user)
     @foreach($user as $app)
    <p><a href="{{url('single/'.$app->project_id)}}">{{$app->project_name}}</a> <span class="price"> ₹{{$app->project_amount}}</span></p>
    <hr>
    @endforeach
      @endisset
      <p>Total <span class="price" style="color:black"><b>{{}}</b></span></p>
  </div>
</div>

        <div class="col-50">
          <h3>Payment</h3>
          <label for="fname">Accepted Cards</label>
          <div class="icon-container">
            <i class="fa fa-cc-visa" style="color:navy;"></i>
            <i class="fa fa-cc-amex" style="color:blue;"></i>
            <i class="fa fa-cc-mastercard" style="color:red;"></i>
            <i class="fa fa-cc-discover" style="color:orange;"></i>
          </div>
          <label for="cname">Name on Card</label>
          <input type="text" id="cname" name="cardname" placeholder="John More Doe">
          <label for="ccnum">Card number</label>
          <input type="text" id="ccnum" name="cardnumber" placeholder="1111-2222-3333-4444">
          <label for="expmonth">Exp Month</label>
          <input type="text" id="expmonth" name="expmonth" placeholder="September">
          <div class="row">
            <div class="col-50">
              <label for="expyear">Exp Year</label>
              <input type="text" id="expyear" name="expyear" placeholder="2018">
            </div>
            <div class="col-50">
              <label for="cvv">CVV</label>
              <input type="text" id="cvv" name="cvv" placeholder="352">
            </div>
          </div>
        </div>
        
      </div>
      <input type="submit" value="Continue to checkout" class="btn">
    </form>
  </div>
</div>

</div>

</body>

  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>