<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
		<link rel="stylesheet" href="customer/css/style.css">
		<style type="text/css">
		.nopad {
	padding-left: 0 !important;
	padding-right: 0 !important;
}
/*image gallery*/
.image-checkbox {
	cursor: pointer;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
	border: 4px solid transparent;
	margin-bottom: 0;
	outline: 0;
}
.image-checkbox input[type="checkbox"] {
	display: none;
}

.image-checkbox-checked {
	border-color: #4783B0;
}
.image-checkbox .fa {
  position: absolute;
  color: #4A79A3;
  background-color: #fff;
  padding: 10px;
  top: 0;
  right: 0;
}
.image-checkbox-checked .fa {
  display: block !important;
}
		.hvrbox,
.hvrbox * {
	box-sizing: border-box;
}
.hvrbox {
	position: relative;
	display: inline-block;
	overflow: hidden;
	max-width: 100%;
	height: auto;
}
.hvrbox img {
	max-width: 100%;
}
.hvrbox .hvrbox-layer_bottom {
	display: block;
}
.hvrbox .hvrbox-layer_top {
	opacity: 0;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.6);
	color: #fff;
	padding: 15px;
	-moz-transition: all 0.4s ease-in-out 0s;
	-webkit-transition: all 0.4s ease-in-out 0s;
	-ms-transition: all 0.4s ease-in-out 0s;
	transition: all 0.4s ease-in-out 0s;
}
.hvrbox:hover .hvrbox-layer_top,
.hvrbox.active .hvrbox-layer_top {
	opacity: 1;
}
.hvrbox .hvrbox-text {
	text-align: center;
	font-size: 18px;
	display: inline-block;
	position: absolute;
	top: 50%;
	left: 50%;
	-moz-transform: translate(-50%, -50%);
	-webkit-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
}
.hvrbox .hvrbox-text_mobile {
	font-size: 15px;
	border-top: 1px solid rgb(179, 179, 179); /* for old browsers */
	border-top: 1px solid rgba(179, 179, 179, 0.7);
	margin-top: 5px;
	padding-top: 2px;
	display: none;
}
.hvrbox.active .hvrbox-text_mobile {
	display: block;
}
.zoomin img {
  height: 500px;
  width: 500px;
  -webkit-transition: all 2s ease;
     -moz-transition: all 2s ease;
      -ms-transition: all 2s ease;
          transition: all 2s ease;
}
.zoomin img:hover {
  width: 500px;
  height: 500px;
}
</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>
    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

		

    <form action="/booking" method="post">
		@csrf
		
    <section class="ftco-section bg-light">
		
    	<div class="container" style="">
			<div class="row">
			@isset($st)
     @foreach($st as $approve)
			<div class="hvrbox" >
			<div class="col-xs-4 col-sm-3 col-md-2 nopad text-center" >
    <label class="image-checkbox"  style="width:500px;">
	<img src="images/{{$approve->interior_pic}}" class="img-responsive" alt="Mountains" class="hvrbox-layer_bottom">
	
    </label>
	<div class="hvrbox-layer_top" style="width:500px;">
		<div class="hvrbox-text"><h6>{{$approve->interior_dec}}</h6></div>
		<h6>₹{{$approve->interior_amount}}</h6>
		<input type="hidden" value="{{$approve->interior_id}}" name="wish"/>
										<p>{{$approve->created_at}}</p>
											
	<?php
$sess=session()->get('reg_id');
$a=$sess;
//echo $p;

?>
									
 <input type="hidden" value="{{$approve->reg_id}}" name="builder"/>
 <input type="hidden" value="{{$a}}" name="reg"/>			
								<?php 
					
						$p=$approve->reg_id;
						
$dt=DB::select("select reg_fname from tbl_reg where reg_id='$p'")
?>
@foreach($dt as $app)
<p>{{$app->reg_fname}}</p>
@endforeach		
<br><br><br><br>
<br><br>

<input type="submit" value="Book Now" name="submit">
							
	</div>
</div>

  </div>		
@endforeach
      @endisset				
    	
			
	    					
   </form> 						
    					
	    						
    				</div>
				
    			</div>
			
				
    		

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
<script>

</script>

  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>