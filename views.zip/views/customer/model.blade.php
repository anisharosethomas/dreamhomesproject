<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="{{asset('customer/css/open-iconic-bootstrap.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/animate.css')}}">
    
    <link rel="stylesheet" href="{{asset('customer/css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/owl.theme.default.min.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/magnific-popup.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/aos.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/ionicons.min.css')}}">

    <link rel="stylesheet" href="{{asset('customer/css/bootstrap-datepicker.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/jquery.timepicker.css')}}">

    
    <link rel="stylesheet" href="{{asset('customer/css/flaticon.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/icomoon.css')}}">
    <link rel="stylesheet" href="{{asset('customer/css/style.css')}}">
		<style type="text/css">
    .row-fluid .adPageChoice .span5.outlineSection, .row-fluid .adPageChoice .span6.outlineSection, .row-fluid .adPageChoice .span8.outlineSection, .row-fluid .adPageChoice .span10.outlineSection, .row-fluid .hubPageChoice .span5.outlineSection, .row-fluid .hubPageChoice .span6.outlineSection, .row-fluid .hubPageChoice .span8.outlineSection, .row-fluid .hubPageChoice .span10.outlineSection, .row-fluid .trialChoice .span5.outlineSection, .row-fluid .trialChoice .span6.outlineSection, .row-fluid .trialChoice .span8.outlineSection, .row-fluid .trialChoice .span10.outlineSection, .row-fluid .whiteCTA .span5.outlineSection, .row-fluid .whiteCTA .span6.outlineSection, .row-fluid .whiteCTA .span8.outlineSection, .row-fluid .whiteCTA .span10.outlineSection {
    background: white;
    padding-left: 35px;
    padding-right: 35px;
}
.row-fluid .outlineSection {
    border: 1px solid #bbb;
    padding-top: 20px;
    padding-left: 60px;
    padding-right: 60px;
    padding-bottom: 30px;
    margin-bottom: 30px;
    text-align: center;
}
.grayRow .outlineSection {
    background: white;
}
.row-fluid .span5 {
    width: 40.5660377358%;
    *width: 40.5188679245%;
}
.row-fluid [class*="span"] {
    display: block;
    width: 100%;
    min-height: 34px;
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;
    float: left;
    padding-left: 10px;
    padding-right: 10px;
}
.span5 {
    width: 430px;
}
[class*="span"] {
    float: left;
    min-height: 1px;
    margin-left: 1.8867924528%;
}
user agent stylesheet
div {
    display: block;
}
.text-center {
    text-align: center;
}
body {
    margin: 0;
    font-family: 'OpenSans';
    font-size: 16px;
    line-height: 24px;
    color: #666;
    background-color: #fff;
    overflow-x: hidden;
    width: auto;
}
:root {
    --purechat-p-bg: #17539e;
    --purechat-p-bg-d: #144788;
    --purechat-p-bg-l: #1a5fb4;
    --purechat-p-fg: #ffffff;
    --purechat-p-fg-l: #ffffff;
    --purechat-s-bg: #f8f7f5;
    --purechat-s-bg-d: #e8e5df;
    --purechat-s-bg-l: #ffffff;
    --purechat-s-fg: #676a6d;
    --purechat-s-fg-l: #3b404c;
    --purechat-s-fg-d: #3b404c;
    --purechat-a-d: #c11e1f;
    --purechat-a-d-bg: #c11e1f;
    --purechat-a-d-fg: #ffffff;
    --purechat-btn-bg: #17539e;
    --purechat-btn-fg: #ffffff;
    --purechat-btn-b: rgba(255,255,255,0.5);
    --purechat-btn-b-h: rgba(255, 255, 255, 1);
}
html {
    font-size: 100%;
    -webkit-text-size-adjust: 100%;
    -ms-text-size-adjust: 100%;
}
    .span5 {
    width: 430px;
}
    .row-fluid.fullBleedRow {
    max-width: none;
}
.row-fluid.fullBleedRow {
    max-width: none;
}
.grayRow {
    background: #eee;
    padding-top: 45px;
    padding-bottom: 35px;
    margin-bottom: 25px;
}
.row-fluid {
    width: 100%;
    *zoom: 1;
}
.row-fluid {
    max-width: 1080px;
    margin: auto;
}
.text-center {
    text-align: center;
}
user agent stylesheet
div {
    display: block;
}
body {
    margin: 0;
    font-family: 'OpenSans';
    font-size: 16px;
    line-height: 24px;
    color: #666;
    background-color: #fff;
    overflow-x: hidden;
    width: auto;
}
    .containers {
  width:900px; 
  height: 150px;
  margin: auto;
  
}
.first-box {
  width:300px; 
  float:left; 
  background: green; 
  height: 150px;
  margin: 50px
}

.first-box p {
  color: #ffffff;
  padding-left: 80px;
  padding-top: 50px;
}

.second-box {
  width:300px; 
  height: 150px; 
  float:right; 
  background: blue;
  margin: 50px
}

.second-box p {
  color: #ffffff;
  padding-left: 110px;
  padding-top: 50px;
}

		.nopad {
	padding-left: 0 !important;
	padding-right: 0 !important;
}
/*image gallery*/
.image-checkbox {
	cursor: pointer;
	box-sizing: border-box;
	-moz-box-sizing: border-box;
	-webkit-box-sizing: border-box;
	border: 4px solid transparent;
	margin-bottom: 0;
	outline: 0;
}
.image-checkbox input[type="checkbox"] {
	display: none;
}

.image-checkbox-checked {
	border-color: #4783B0;
}
.image-checkbox .fa {
  position: absolute;
  color: #4A79A3;
  background-color: #fff;
  padding: 10px;
  top: 0;
  right: 0;
}
.image-checkbox-checked .fa {
  display: block !important;
}
		.hvrbox,
.hvrbox * {
	box-sizing: border-box;
}
.hvrbox {
	position: relative;
	display: inline-block;
	overflow: hidden;
	max-width: 100%;
	height: auto;
}
.hvrbox img {
	max-width: 100%;
}
.hvrbox .hvrbox-layer_bottom {
	display: block;
}
.hvrbox .hvrbox-layer_top {
	opacity: 0;
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	width: 100%;
	height: 100%;
	background: rgba(0, 0, 0, 0.6);
	color: #fff;
	padding: 15px;
	-moz-transition: all 0.4s ease-in-out 0s;
	-webkit-transition: all 0.4s ease-in-out 0s;
	-ms-transition: all 0.4s ease-in-out 0s;
	transition: all 0.4s ease-in-out 0s;
}
.hvrbox:hover .hvrbox-layer_top,
.hvrbox.active .hvrbox-layer_top {
	opacity: 1;
}
.hvrbox .hvrbox-text {
	text-align: center;
	font-size: 18px;
	display: inline-block;
	position: absolute;
	top: 50%;
	left: 50%;
	-moz-transform: translate(-50%, -50%);
	-webkit-transform: translate(-50%, -50%);
	-ms-transform: translate(-50%, -50%);
	transform: translate(-50%, -50%);
}
.hvrbox .hvrbox-text_mobile {
	font-size: 15px;
	border-top: 1px solid rgb(179, 179, 179); /* for old browsers */
	border-top: 1px solid rgba(179, 179, 179, 0.7);
	margin-top: 5px;
	padding-top: 2px;
	display: none;
}
.hvrbox.active .hvrbox-text_mobile {
	display: block;
}
.zoomin img {
  height: 500px;
  width: 500px;
  -webkit-transition: all 2s ease;
     -moz-transition: all 2s ease;
      -ms-transition: all 2s ease;
          transition: all 2s ease;
}
.zoomin img:hover {
  width: 500px;
  height: 500px;
}
</style>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

		
    
    <?php
    	  $sess=session()->get('reg_id');
        $a=$sess;
    ?>
   
		<div class="containers">
    <div class="row-fluid">
        <div class="span1"></div>
        <div class="span10">
            <h2 class="grayHeader">Four ways to Choose</h2>
        </div>
        <div class="span1"></div>
    </div>
    <form action="/how" method="post">
    @csrf
    <input type="hidden" name="land" value="{{$id}}"/>
    <input type="hidden" name="reg" value="{{$a}}"/>
    <div class="row-fluid trialChoice">
        <div class="span1"></div>
        <div class="span5 outlineSection browserSection trialOption">
            <h4><a id="cloudText" href="https://cloud.smartdraw.com/" target="_blank">Draw a Floor Plan by Yours </a></h4>
            <input type="submit" class="btn btn-green" value="Start Now"/>
        </div>
        </form>
        <form action="/explans" method="post">
        @csrf
        <input type="hidden" name="land" value="{{$id}}"/>
    <input type="hidden" name="reg" value="{{$a}}"/>
        <div class="span5 outlineSection downloadSection trialOption">
            <h4><a id="downloadText" href="/downloads/download.htm">Select the Plan Drawn By Experts</a></h4>
            <input type="submit" class="btn btn-blue" value="See"/>
         
        </div>
        </form>

        <form action="/payment" method="post">
        @csrf
        <input type="hidden" name="land" value="{{$id}}"/>
        <input type="hidden" name="reg" value="{{$a}}"/>
        <div class="span5 outlineSection downloadSection trialOption">
            <h4><a id="downloadText" href="/downloads/download.htm">Buy the Land</a></h4>
            <input type="submit" class="btn btn-blue" value="Buy Now"/>
            
          </form>    </div>
    </div>
</div>
    <p></p>
  </div>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>
<script>

</script>

<script src="{{asset('customer/js/jquery.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery-migrate-3.0.1.min.js')}}"></script>
  <script src="{{asset('customer/js/popper.min.js')}}"></script>
  <script src="{{asset('customer/js/bootstrap.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.easing.1.3.js')}}"></script>
  <script src="{{asset('customer/js/jquery.waypoints.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.stellar.min.js')}}"></script>
  <script src="{{asset('customer/js/owl.carousel.min.js')}}"></script>
  <script src="{{asset('customer/js/jquery.magnific-popup.min.js')}}"></script>
  <script src="{{asset('customer/js/aos.js')}}"></script>
  <script src="{{asset('customer/js/jquery.animateNumber.min.js')}}"></script>
  <script src="{{asset('customer/js/bootstrap-datepicker.js')}}"></script>
  <script src="{{asset('customer/js/jquery.timepicker.min.js')}}"></script>
  <script src="{{asset('customer/js/scrollax.min.js')}}"></script>
  <script src="{{asset('customer/js/google-map.js')}}"></script>
  <script src="{{asset('customer/js/main.js')}}"></script>
  </body>
</html>