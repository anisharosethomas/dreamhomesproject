<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

	
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
      
    <section class="ftco-section bg-light">
		<?php
         $sess=session()->get('reg_id');
         $a=$sess;
         $st=DB::select("select * from tbl_land where reg_id !='$a' and land_status='0'");
        ?>
    	<div class="container">

    		<div class="row">
				@isset($st)
     @foreach($st as $approve)
    			<div class="col-md-4 ftco-animate">
    				<div class="properties"  >
                    <div class="single-slider owl-carousel">
                    
    					<a href="{{url('model/'.$approve->land_id)}}" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/{{$approve->land_pic1}});" value="{{url($approve->land_id)}}" height="42" width="42">
                        
                        <a href="{{url('model/'.$approve->land_id)}}" class="img img-2 d-flex justify-content-center align-items-center" style="background-image: url(images/{{$approve->land_pic2}});" value="{{url($approve->land_id)}}">
    						
                            <div class="icon d-flex justify-content-center align-items-center">
    							<span class="icon-search2"></span>
    						</div>
    					</a>
                        </div>
    					<div class="text p-3" style="float:right;">
    						<span class="status sale">Sale</span>
    						<div class="d-flex" >
    							<div class="one">
		    						<h3><a href="{{url('model/'.$approve->land_id)}}">{{$approve->land_add}}</a></h3>
		    						
	    						</div>
	    						<div class="two">
	    							<span class="price"> {{$approve->land_ac}} CENT</span><br>
										₹{{$approve->land_per}}per cent
										</div>
    						</div>
										<?php 
						foreach($st as $s){
						$p=$s->reg_id;
						
						}
$dt=DB::select("select * from tbl_reg where reg_id='$p'")
?>
@foreach($dt as $app)
										<p style="color:red;">{{$app->reg_fname}} {{$app->reg_sname}}  - {{$app->reg_mob}}</p>
                                        
										@endforeach							
    						

    						<p>{{$approve->land_about}}</p>
    						<hr>
    						<p class="bottom-area d-flex">
    							<span  style="color:blue;">Land Facing  :   {{$approve->land_facing}}<br>
    							No. of Floors can be constructed  :  {{$approve->land_floor}} <br>
								Distance from Road to Plot :  {{$approve->land_road}}<br>
                                
								Boundary Wall :   {{$approve->land_wall}}</span>
    						</p>
    					</div>
    				</div>
						
    			</div>
					@endforeach
      @endisset
			</div>
		
		</div>
    <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


<script src="customer/js/jquery.min.js"></script>
<script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
<script src="customer/js/popper.min.js"></script>
<script src="customer/js/bootstrap.min.js"></script>
<script src="customer/js/jquery.easing.1.3.js"></script>
<script src="customer/js/jquery.waypoints.min.js"></script>
<script src="customer/js/jquery.stellar.min.js"></script>
<script src="customer/js/owl.carousel.min.js"></script>
<script src="customer/js/jquery.magnific-popup.min.js"></script>
<script src="customer/js/aos.js"></script>
<script src="customer/js/jquery.animateNumber.min.js"></script>
<script src="customer/js/bootstrap-datepicker.js"></script>
<script src="customer/js/jquery.timepicker.min.js"></script>
<script src="customer/js/scrollax.min.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
<script src="customer/js/google-map.js"></script>
<script src="customer/js/main.js"></script>
  
</body>
</html>		