<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Dream Home</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		<script>
    var msg = '{{Session::get('alert')}}';
    var exist = '{{Session::has('alert')}}';
    if(exist){
      alert(msg);
    }
  </script>
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>


    
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>

    <!-- END nav -->
    <section  class="ftco-section">
		<img src="/img/loan.jpg">
    <h2>Home Loan Guide</h2>
    <p>A Comprehensive Home Loan Guide For First Time Home Buyers In India.</p>
  </a>
	@isset($st)
     @foreach($st as $approve)
    <h6 style="color:red;"><b> {{$approve->loan_type}}</b></h6>
     <p>{{$approve->loan_dec}}</p>
     @endforeach
     @endisset
    </section>
	
    

  

  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>