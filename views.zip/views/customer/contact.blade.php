<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Dream Home- Profile</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

    <link rel="stylesheet" href="customer/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="customer/css/animate.css">
    
    <link rel="stylesheet" href="customer/css/owl.carousel.min.css">
    <link rel="stylesheet" href="customer/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="customer/css/magnific-popup.css">

    <link rel="stylesheet" href="customer/css/aos.css">

    <link rel="stylesheet" href="customer/css/ionicons.min.css">

    <link rel="stylesheet" href="customer/css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="customer/css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="customer/css/flaticon.css">
    <link rel="stylesheet" href="customer/css/icomoon.css">
		<link rel="stylesheet" href="customer/css/style.css">
		
  </head>
  <body>
    <div class="top">
    	<div class="container">
    		<div class="row d-flex align-items-center">
    			
    			<div class="col d-flex justify-content-end">
    				<p class="num"><span class="icon-phone"></span> + 9497626357</p>
    			</div>
    		</div>
    	</div>
    </div>

    

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="/index">Dream<span>Home</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span>Menu
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
	          <li class="nav-item active"><a href="/index" class="nav-link">Home</a></li>
	          
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/project" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Projects
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/ongoing" class="trigger-btn" title="">Ongoing</a>
                                <a class="dropdown-item " href="/upcome" class="trigger-btn" title="">Upcoming</a>
																<a class="dropdown-item " href="/complete"  class="trigger-btn" title="">Completed</a>
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Interiors
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                                <a class="dropdown-item " href="/interiors" class="trigger-btn" title="">Home</a>
                                <a class="dropdown-item " href="/old" class="trigger-btn" title="">Old Home</a>
																<a class="dropdown-item " href="/office"  class="trigger-btn" title="">Office</a>
																<a class="dropdown-item " href="/church"  class="trigger-btn"  title="">Church</a>
                            </div>
                        </li>
					<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Land
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">  
                                <a class="dropdown-item " href="/landa" class="trigger-btn"  title="">Add Your Land</a>
														    <a class="dropdown-item " href="/lands" class="trigger-btn"  title="">Buy Your Dream Land</a>
                                <a class="dropdown-item " href="/myland" class="trigger-btn" title="">My Land</a>
                                <a class="dropdown-item " href="/mycredit" class="trigger-btn" title="">My Credits</a>
                            </div>
                        </li>
                        <li class="nav-item"><a href="/how" class="nav-link">Draw Plans</a></li>
                        <li class="nav-item"><a href="/require" class="nav-link">Plan</a></li>
	                       <li class="nav-item"><a href="/budget" class="nav-link">Budget</a></li>
					            	<li class="nav-item"><a href="/loan" class="nav-link">Loan</a></li>
            
					
						<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="/wish" id="navbarDropdown1" role="button" >
                                    Wish
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">
                               
                               
                                <a class="dropdown-item " href="/myorder" class="trigger-btn" title="">My Orders</a>
                                <a class="dropdown-item " href="/mybook" class="trigger-btn" title="">My Bookings</a>
                                <a class="dropdown-item " href="/budgetmy" class="trigger-btn" title="">My Budget & My Plans</a>
                               
                                
                            </div>
                        </li>
												<li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle " href="#" id="navbarDropdown1" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
														{{Session::get('reg_fname')}}
                                        <!-- <i class="fas fa-angle-down"></i> -->
                                    </a>
                            <div class="dropdown-menu active" aria-labelledby="navbarDropdown">

                              
                                <a class="dropdown-item " href="/profilec" class="trigger-btn"  title="">Profile</a>
																<a class="dropdown-item " href="/updatepass"  class="trigger-btn"  title="">Change Password</a>
																<a class="dropdown-item " href="/logout"  class="trigger-btn"  title="">Logout</a>
                            </div>
                        </li>

	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->

    <?php
                                        use App\login;
                                        $sess=session()->get('reg_fname');
                                        $a=$sess;
                                        $st=DB::select("select * from logins,tbl_reg where reg_fname='$a'");
                                       // $name = DB::table('tbl_regs')->where('r_id', $reg_id)->pluck('name');
                                      foreach($st as $object)
                                        {
                                            $log_id=$object->login_id;
                                            $reg_id=$object->reg_id;
                                        } 
                                       $user = DB::table('tbl_reg')->where('reg_id', $reg_id)->first();
                                        
                                    ?>
	 
    <div class="col-md-9">
		    <div class="card">
		        <div class="card-body">
		            <div class="row">
		                <div class="col-md-12">
		                    <h4>Your Profile</h4>
		                    <hr>
		                </div>
		            </div>
           
		            <div class="row">
		                <div class="col-md-12">
		                    <form method="post" action="{{url('/updatec')}}">
                        {{ csrf_field() }}
                              <div class="form-group row">
                                <label for="name" class="col-4 col-form-label">First Name</label> 
                                <div class="col-8">
                                  <input id="name" name="email" placeholder="First Name" class="form-control here" type="text" value="{{$user->reg_fname}}" disabled>
                                  <input type="hidden" name="email" value="{{$user->reg_fname}}">

                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="lastname" class="col-4 col-form-label">Last Name</label> 
                                <div class="col-8">
                                  <input id="lastname" name="lastname" placeholder="Last Name" class="form-control here" type="text" value="{{$user->reg_sname}}" disabled>
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="text" class="col-4 col-form-label">Mobile Number*</label> 
                                <div class="col-8">
                                  <input id="text"  placeholder="Nick Name" class="form-control here" required="required" type="text" value="{{$user->reg_mob}}" disabled>
                                </div>
                              </div>
                           
                             
                              <div class="form-group row">
                                <label for="email" class="col-4 col-form-label">Location*</label> 
                                <div class="col-8">
                                  <input id="email"  placeholder="Location" class="form-control here" required="required" type="text" name="loc">
                                </div>
                              </div>
                              <div class="form-group row">
                                <label for="email" class="col-4 col-form-label">Address*</label> 
                                <div class="col-8">
                                  <input id="email"  placeholder="Address" class="form-control here" required="required" type="text" name="address">
                                </div>
                              </div>
                                
                              <div class="form-group row">
                                <div class="offset-4 col-8">
                                  <button name="submit" type="submit" class="btn btn-primary">Update My Profile</button>
                                </div>
                              </div>
                             
                            </form>
		                </div>
		            </div>
		            
		        </div>
		    </div>
		</div>
  


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="customer/js/jquery.min.js"></script>
  <script src="customer/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="customer/js/popper.min.js"></script>
  <script src="customer/js/bootstrap.min.js"></script>
  <script src="customer/js/jquery.easing.1.3.js"></script>
  <script src="customer/js/jquery.waypoints.min.js"></script>
  <script src="customer/js/jquery.stellar.min.js"></script>
  <script src="customer/js/owl.carousel.min.js"></script>
  <script src="customer/js/jquery.magnific-popup.min.js"></script>
  <script src="customer/js/aos.js"></script>
  <script src="customer/js/jquery.animateNumber.min.js"></script>
  <script src="customer/js/bootstrap-datepicker.js"></script>
  <script src="customer/js/jquery.timepicker.min.js"></script>
  <script src="customer/js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="customer/js/google-map.js"></script>
  <script src="customer/js/main.js"></script>
    
  </body>
</html>